<?php
header("Content-Type: application/json");
include "db.php";

$id = $_GET["digital_id"] ?? "";

if (!$id) {
    echo json_encode(["success" => false, "message" => "Digital ID required"]);
    exit;
}

$sql = "SELECT * FROM tourists WHERE digital_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(["success" => true, "data" => $row]);
} else {
    echo json_encode(["success" => false, "message" => "Tourist not found"]);
}
?>
