<?php
$host = "localhost";   // or 127.0.0.1
$user = "root";        // your MySQL username
$pass = "";            // your MySQL password
$dbname = "tourist_db"; // database you created

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
