<?php
header("Content-Type: application/json");
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$type     = $data["tourist_type"] ?? "";
$name     = $data["full_name"] ?? "";
$aadhaar  = $data["aadhaar_number"] ?? null;
$passport = $data["passport_number"] ?? null;
$contact  = $data["emergency_contact"] ?? "";
$start    = $data["trip_start"] ?? "";
$end      = $data["trip_end"] ?? "";
$hotel    = $data["hotel_details"] ?? "";
$vehicle  = $data["vehicle_driver_info"] ?? "";

// Generate Digital ID
$digital_id = "TID" . time();

// Validation
if (!$type || !$name || !$contact || !$start || !$end) {
    echo json_encode(["success" => false, "message" => "All required fields must be filled"]);
    exit;
}

if ($type === "Local Tourist (Aadhaar)" && !$aadhaar) {
    echo json_encode(["success" => false, "message" => "Aadhaar number required"]);
    exit;
}

if ($type === "Foreign Tourist (Passport)" && !$passport) {
    echo json_encode(["success" => false, "message" => "Passport number required"]);
    exit;
}

$sql = "INSERT INTO tourists (tourist_type, full_name, aadhaar_number, passport_number, emergency_contact, trip_start, trip_end, hotel_details, vehicle_driver_info, digital_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssss", $type, $name, $aadhaar, $passport, $contact, $start, $end, $hotel, $vehicle, $digital_id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Tourist registered successfully",
        "digital_id" => $digital_id
    ]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
