// SafeTour - Tourist Safety WebApp
// Main JavaScript Application

// Global Variables
let map;
let userMarker;
let trackingActive = false;
let userLocation = null;
let destinations = [];
let restrictedZones = [];
let sosLogs = [];
let checkinHistory = [];
let digitalId = null;
let currentLanguage = 'en';

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    console.log('SafeTour App Initializing...');
    
    // Load stored data
    loadStoredData();
    
    // Initialize map
    initializeMap();
    
    // Set up event listeners
    setupEventListeners();
    
    // Start location tracking
    startLocationTracking();
    
    // Update dashboard
    updateDashboard();
    
    // Initialize internationalization
    initializeI18n();
    
    // Set up periodic checks
    setupPeriodicChecks();
    
    console.log('SafeTour App Initialized Successfully');
}

// ===========================================
// STORAGE MANAGEMENT
// ===========================================

function loadStoredData() {
    try {
        digitalId = JSON.parse(localStorage.getItem('digitalId')) || null;
        destinations = JSON.parse(localStorage.getItem('destinations')) || [];
        restrictedZones = JSON.parse(localStorage.getItem('restrictedZones')) || [];
        sosLogs = JSON.parse(localStorage.getItem('sosLogs')) || [];
        checkinHistory = JSON.parse(localStorage.getItem('checkinHistory')) || [];
        currentLanguage = localStorage.getItem('language') || 'en';
        
        // Populate UI with stored data
        if (digitalId) {
            displayDigitalId();
        }
        updateDestinationsList();
        updateZonesList();
        updateSosLogsList();
        updateCheckinHistory();
        
    } catch (error) {
        console.error('Error loading stored data:', error);
    }
}

function saveData(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error('Error saving data:', error);
        showToast('Storage error occurred', 'error');
    }
}

// ===========================================
// MAP FUNCTIONALITY
// ===========================================

function initializeMap() {
    // Initialize map centered on India
    map = L.map('mapDiv').setView([20.5937, 78.9629], 5);
    
    // Add tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Add user location marker
    userMarker = L.marker([0, 0], {
        icon: L.divIcon({
            className: 'user-location-marker',
            html: '<i class="fas fa-user" style="color: #3b82f6;"></i>',
            iconSize: [20, 20]
        })
    }).addTo(map);
    
    // Load and display destinations and zones on map
    updateMapMarkers();
    
    console.log('Map initialized');
}

function updateMapMarkers() {
    // Clear existing markers (except user marker)
    map.eachLayer(layer => {
        if (layer !== userMarker && layer._url === undefined) {
            map.removeLayer(layer);
        }
    });
    
    // Add destination markers
    destinations.forEach((dest, index) => {
        if (dest.lat && dest.lng) {
            const marker = L.marker([dest.lat, dest.lng], {
                icon: L.divIcon({
                    className: 'destination-marker',
                    html: '<i class="fas fa-map-pin" style="color: #10b981;"></i>',
                    iconSize: [20, 20]
                })
            }).addTo(map);
            
            marker.bindPopup(`
                <div class="marker-popup">
                    <h4>${dest.name}</h4>
                    <p>Planned: ${new Date(dest.visitTime).toLocaleString()}</p>
                    <button onclick="removeDestination(${index})" class="btn-sm btn-danger">Remove</button>
                </div>
            `);
        }
    });
    
    // Add restricted zone markers
    restrictedZones.forEach((zone, index) => {
        const circle = L.circle([zone.lat, zone.lng], {
            color: zone.riskLevel === 'extreme' ? '#ef4444' : '#f97316',
            fillColor: zone.riskLevel === 'extreme' ? '#ef4444' : '#f97316',
            fillOpacity: 0.3,
            radius: zone.radius,
            className: 'restricted-zone blinking'
        }).addTo(map);
        
        circle.bindPopup(`
            <div class="marker-popup">
                <h4>${zone.name}</h4>
                <p>Risk Level: ${zone.riskLevel}</p>
                <p>Radius: ${zone.radius}m</p>
                <button onclick="removeZone(${index})" class="btn-sm btn-danger">Remove</button>
            </div>
        `);
    });
}

function centerOnUser() {
    if (userLocation) {
        map.setView([userLocation.lat, userLocation.lng], 15);
        showToast('Centered on your location', 'success');
    } else {
        showToast('Location not available', 'error');
    }
}

function toggleTracking() {
    trackingActive = !trackingActive;
    const statusElement = document.getElementById('trackingStatus');
    
    if (trackingActive) {
        statusElement.textContent = 'Active';
        statusElement.className = 'status-badge active';
        showToast('Location tracking enabled', 'success');
    } else {
        statusElement.textContent = 'Inactive';
        statusElement.className = 'status-badge';
        showToast('Location tracking disabled', 'info');
    }
}

// ===========================================
// LOCATION TRACKING
// ===========================================

function startLocationTracking() {
    if ('geolocation' in navigator) {
        const options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 60000
        };
        
        navigator.geolocation.watchPosition(
            updateUserLocation,
            handleLocationError,
            options
        );
    } else {
        showToast('Geolocation not supported', 'error');
    }
}

function updateUserLocation(position) {
    userLocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: Date.now()
    };
    
    // Update user marker on map
    userMarker.setLatLng([userLocation.lat, userLocation.lng]);
    
    // Update UI elements
    document.getElementById('currentCoords').textContent = 
        `${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}`;
    document.getElementById('lastLocationUpdate').textContent = 
        new Date().toLocaleTimeString();
    document.getElementById('currentLocation').textContent = 
        `${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}`;
    
    // Check for restricted zones
    checkRestrictedZones();
    
    // Check route deviations
    checkRouteDeviations();
    
    console.log('Location updated:', userLocation);
}

function handleLocationError(error) {
    console.error('Location error:', error);
    showToast('Location access error', 'error');
}

// ===========================================
// DIGITAL ID MANAGEMENT
// ===========================================

function setupEventListeners() {
    // Digital ID form
    document.getElementById('registrationForm').addEventListener('submit', handleRegistration);
    
    // Tourist type change
    document.getElementById('touristType').addEventListener('change', function() {
        const label = document.getElementById('idNumberLabel');
        const input = document.getElementById('idNumber');
        
        if (this.value === 'foreign') {
            label.textContent = 'Passport Number:';
            input.placeholder = 'Passport Number';
        } else {
            label.textContent = 'Aadhaar Number:';
            input.placeholder = 'Aadhaar Number';
        }
    });
    
    // Destination form
    document.getElementById('destinationForm').addEventListener('submit', handleDestinationAdd);
    
    // Zone form
    document.getElementById('zoneForm').addEventListener('submit', handleZoneAdd);
    
    // Schedule form
    document.getElementById('scheduleForm').addEventListener('submit', handleScheduleAdd);
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            switchSection(item.dataset.section);
        });
    });
    
    // Mobile menu
    document.getElementById('mobileMenuToggle').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('active');
    });
    
    document.getElementById('closeSidebar').addEventListener('click', () => {
        document.getElementById('sidebar').classList.remove('active');
    });
    
    // Language toggle
    document.getElementById('langToggle').addEventListener('click', toggleLanguage);
}

function handleRegistration(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const registrationData = {
        touristType: document.getElementById('touristType').value,
        fullName: document.getElementById('fullName').value,
        idNumber: document.getElementById('idNumber').value,
        emergencyContact: document.getElementById('emergencyContact').value,
        tripStart: document.getElementById('tripStart').value,
        tripEnd: document.getElementById('tripEnd').value,
        hotelDetails: document.getElementById('hotelDetails').value,
        vehicleInfo: document.getElementById('vehicleInfo').value,
        createdAt: Date.now()
    };
    
    // Generate unique tourist ID
    const touristId = generateTouristId();
    
    digitalId = {
        ...registrationData,
        touristId: touristId,
        status: 'active',
        qrCode: JSON.stringify({
            touristId: touristId,
            name: registrationData.fullName,
            validity: `${registrationData.tripStart} to ${registrationData.tripEnd}`,
            emergency: registrationData.emergencyContact
        })
    };
    
    // Save to localStorage
    saveData('digitalId', digitalId);
    
    // Display the ID
    displayDigitalId();
    
    // Update dashboard
    updateDashboard();
    
    showToast('Digital ID created successfully!', 'success');
    
    // TODO: Integrate with blockchain for tamper-proof storage
    console.log('TODO: Store Digital ID on blockchain', digitalId);
}

function generateTouristId() {
    const prefix = 'ST'; // SafeTour
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substr(2, 4).toUpperCase();
    return `${prefix}${timestamp}${random}`;
}

function displayDigitalId() {
    if (!digitalId) return;
    
    // Hide registration form, show ID card
    document.getElementById('registrationCard').style.display = 'none';
    document.getElementById('idCard').style.display = 'block';
    
    // Populate ID fields
    document.getElementById('displayName').textContent = digitalId.fullName;
    document.getElementById('displayIdNumber').textContent = digitalId.idNumber;
    document.getElementById('displayTouristId').textContent = digitalId.touristId;
    document.getElementById('displayValidity').textContent = 
        `${digitalId.tripStart} to ${digitalId.tripEnd}`;
    
    // Generate QR Code
    generateQRCode();
}

function generateQRCode() {
    const qrContainer = document.getElementById('qrCodeContainer');
    qrContainer.innerHTML = '';
    
    if (typeof QRCode !== 'undefined') {
        QRCode.toCanvas(qrContainer, digitalId.qrCode, {
            width: 150,
            height: 150,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            }
        }, function(error) {
            if (error) {
                console.error('QR Code generation error:', error);
                qrContainer.innerHTML = '<p>QR Code generation failed</p>';
            }
        });
    } else {
        // Fallback QR code placeholder
        qrContainer.innerHTML = `
            <div style="width: 150px; height: 150px; border: 2px solid #ccc; display: flex; align-items: center; justify-content: center;">
                <span>QR Code</span>
            </div>
        `;
    }
}

function downloadId() {
    if (!digitalId) {
        showToast('No ID available to download', 'error');
        return;
    }
    
    const idData = {
        ...digitalId,
        downloadedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(idData, null, 2)], {
        type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SafeTour_ID_${digitalId.touristId}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('Digital ID downloaded', 'success');
}

function resetId() {
    if (confirm('Are you sure you want to reset your Digital ID? This action cannot be undone.')) {
        digitalId = null;
        localStorage.removeItem('digitalId');
        
        document.getElementById('registrationCard').style.display = 'block';
        document.getElementById('idCard').style.display = 'none';
        document.getElementById('registrationForm').reset();
        
        updateDashboard();
        showToast('Digital ID reset successfully', 'info');
    }
}

// ===========================================
// EXPLORATION MANAGEMENT
// ===========================================

function handleDestinationAdd(e) {
    e.preventDefault();
    
    const name = document.getElementById('destName').value;
    let lat = parseFloat(document.getElementById('destLat').value);
    let lng = parseFloat(document.getElementById('destLng').value);
    const visitTime = document.getElementById('visitTime').value;
    
    // If coordinates not provided, use geocoding or current location
    if (!lat || !lng) {
        if (userLocation) {
            lat = userLocation.lat + (Math.random() - 0.5) * 0.01;
            lng = userLocation.lng + (Math.random() - 0.5) * 0.01;
        } else {
            showToast('Please provide coordinates or enable location', 'error');
            return;
        }
    }
    
    const destination = {
        id: Date.now(),
        name: name,
        lat: lat,
        lng: lng,
        visitTime: visitTime,
        status: 'planned',
        createdAt: Date.now()
    };
    
    destinations.push(destination);
    saveData('destinations', destinations);
    updateDestinationsList();
    updateMapMarkers();
    updateDashboard();
    
    document.getElementById('destinationForm').reset();
    showToast('Destination added successfully', 'success');
}

function updateDestinationsList() {
    const container = document.getElementById('destinationsList');
    
    if (destinations.length === 0) {
        container.innerHTML = '<p class="empty-state">No destinations planned yet</p>';
        return;
    }
    
    container.innerHTML = destinations.map((dest, index) => `
        <div class="destination-item">
            <div class="destination-info">
                <div class="destination-name">${dest.name}</div>
                <div class="destination-coords">${dest.lat.toFixed(4)}, ${dest.lng.toFixed(4)}</div>
                <div class="destination-time">${new Date(dest.visitTime).toLocaleString()}</div>
            </div>
            <div class="item-actions">
                <button class="item-btn" onclick="showDestinationOnMap(${index})" title="Show on Map">
                    <i class="fas fa-map"></i>
                </button>
                <button class="item-btn" onclick="removeDestination(${index})" title="Remove">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function showDestinationOnMap(index) {
    const dest = destinations[index];
    if (dest && dest.lat && dest.lng) {
        map.setView([dest.lat, dest.lng], 15);
        switchSection('map');
        showToast(`Showing ${dest.name} on map`, 'info');
    }
}

function removeDestination(index) {
    if (confirm('Remove this destination?')) {
        destinations.splice(index, 1);
        saveData('destinations', destinations);
        updateDestinationsList();
        updateMapMarkers();
        updateDashboard();
        showToast('Destination removed', 'info');
    }
}

// ===========================================
// RESTRICTED ZONES MANAGEMENT
// ===========================================

function handleZoneAdd(e) {
    e.preventDefault();
    
    const zone = {
        id: Date.now(),
        name: document.getElementById('zoneName').value,
        lat: parseFloat(document.getElementById('zoneLat').value),
        lng: parseFloat(document.getElementById('zoneLng').value),
        radius: parseInt(document.getElementById('zoneRadius').value),
        riskLevel: document.getElementById('riskLevel').value,
        createdAt: Date.now(),
        active: true
    };
    
    restrictedZones.push(zone);
    saveData('restrictedZones', restrictedZones);
    updateZonesList();
    updateMapMarkers();
    updateDashboard();
    
    document.getElementById('zoneForm').reset();
    showToast('Restricted zone added', 'warning');
}

function updateZonesList() {
    const container = document.getElementById('zonesList');
    
    if (restrictedZones.length === 0) {
        container.innerHTML = '<p class="empty-state">No restricted zones defined</p>';
        return;
    }
    
    container.innerHTML = restrictedZones.map((zone, index) => `
        <div class="zone-item">
            <div class="zone-info">
                <div class="zone-name">${zone.name}</div>
                <div class="zone-coords">${zone.lat.toFixed(4)}, ${zone.lng.toFixed(4)}</div>
                <div class="zone-details">Radius: ${zone.radius}m | Risk: ${zone.riskLevel}</div>
            </div>
            <div class="item-actions">
                <button class="item-btn" onclick="showZoneOnMap(${index})" title="Show on Map">
                    <i class="fas fa-map"></i>
                </button>
                <button class="item-btn" onclick="removeZone(${index})" title="Remove">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function showZoneOnMap(index) {
    const zone = restrictedZones[index];
    if (zone) {
        map.setView([zone.lat, zone.lng], 15);
        switchSection('map');
        showToast(`Showing ${zone.name} restricted zone`, 'warning');
    }
}

function removeZone(index) {
    if (confirm('Remove this restricted zone?')) {
        restrictedZones.splice(index, 1);
        saveData('restrictedZones', restrictedZones);
        updateZonesList();
        updateMapMarkers();
        updateDashboard();
        showToast('Restricted zone removed', 'info');
    }
}

function checkRestrictedZones() {
    if (!userLocation) return;
    
    restrictedZones.forEach(zone => {
        const distance = calculateDistance(
            userLocation.lat, userLocation.lng,
            zone.lat, zone.lng
        );
        
        if (distance <= zone.radius) {
            handleZoneViolation(zone);
        }
    });
}

function handleZoneViolation(zone) {
    const lastAlert = localStorage.getItem(`zone_alert_${zone.id}`);
    const now = Date.now();
    
    // Don't spam alerts - minimum 5 minutes between alerts for same zone
    if (lastAlert && (now - parseInt(lastAlert)) < 300000) {
        return;
    }
    
    localStorage.setItem(`zone_alert_${zone.id}`, now.toString());
    
    showToast(`⚠️ WARNING: You've entered restricted zone: ${zone.name}`, 'error');
    
    // Auto-escalate to SOS after 30 seconds if no response
    setTimeout(() => {
        if (confirm(`You're still in restricted zone "${zone.name}". Trigger SOS?`)) {
            triggerAutoSOS(`Restricted zone violation: ${zone.name}`);
        }
    }, 30000);
}

// ===========================================
// CHECK-IN MANAGEMENT
// ===========================================

function performCheckin() {
    if (!userLocation) {
        showToast('Location required for check-in', 'error');
        return;
    }
    
    const checkin = {
        id: Date.now(),
        type: 'checkin',
        timestamp: Date.now(),
        location: userLocation,
        touristId: digitalId?.touristId || 'unregistered',
        status: 'completed'
    };
    
    checkinHistory.push(checkin);
    saveData('checkinHistory', checkinHistory);
    updateCheckinHistory();
    updateDashboard();
    
    showToast('Check-in successful', 'success');
}

function performCheckout() {
    if (!userLocation) {
        showToast('Location required for check-out', 'error');
        return;
    }
    
    const checkout = {
        id: Date.now(),
        type: 'checkout',
        timestamp: Date.now(),
        location: userLocation,
        touristId: digitalId?.touristId || 'unregistered',
        status: 'completed'
    };
    
    checkinHistory.push(checkout);
    saveData('checkinHistory', checkinHistory);
    updateCheckinHistory();
    updateDashboard();
    
    showToast('Check-out successful', 'success');
}

function handleScheduleAdd(e) {
    e.preventDefault();
    
    const expectedCheckin = new Date(document.getElementById('expectedCheckin').value);
    const expectedCheckout = new Date(document.getElementById('expectedCheckout').value);
    
    if (expectedCheckout <= expectedCheckin) {
        showToast('Check-out time must be after check-in time', 'error');
        return;
    }
    
    const schedule = {
        id: Date.now(),
        expectedCheckin: expectedCheckin.getTime(),
        expectedCheckout: expectedCheckout.getTime(),
        status: 'scheduled',
        createdAt: Date.now()
    };
    
    checkinHistory.push(schedule);
    saveData('checkinHistory', checkinHistory);
    updateCheckinHistory();
    
    document.getElementById('scheduleForm').reset();
    showToast('Check-in scheduled successfully', 'success');
    
    // Set up reminder/check
    scheduleCheckinReminder(schedule);
}

function scheduleCheckinReminder(schedule) {
    const now = Date.now();
    const checkinTime = schedule.expectedCheckin;
    const timeUntilCheckin = checkinTime - now;
    
    // Set reminder 30 minutes after expected check-in time
    if (timeUntilCheckin > 0) {
        setTimeout(() => {
            checkMissedCheckin(schedule);
        }, timeUntilCheckin + 1800000); // 30 minutes after expected time
    }
}

function checkMissedCheckin(schedule) {
    // Check if user actually checked in
    const actualCheckin = checkinHistory.find(item => 
        item.type === 'checkin' && 
        Math.abs(item.timestamp - schedule.expectedCheckin) < 3600000 // Within 1 hour
    );
    
    if (!actualCheckin) {
        handleMissedCheckin(schedule);
    }
}

function handleMissedCheckin(schedule) {
    const modal = confirm(`You missed your scheduled check-in at ${new Date(schedule.expectedCheckin).toLocaleString()}. Are you safe?`);
    
    if (!modal) {
        // No response - trigger SOS and generate E-FIR
        triggerAutoSOS('Missed check-in');
        generateEFIRForMissedCheckin(schedule);
    } else {
        showToast('Thank you for confirming your safety', 'success');
    }
}

function updateCheckinHistory() {
    const container = document.getElementById('checkinHistory');
    
    if (checkinHistory.length === 0) {
        container.innerHTML = '<p class="empty-state">No check-in history available</p>';
        return;
    }
    
    // Sort by timestamp, most recent first
    const sortedHistory = [...checkinHistory].sort((a, b) => b.timestamp - a.timestamp);
    
    container.innerHTML = sortedHistory.slice(0, 10).map(item => `
        <div class="checkin-item">
            <div class="checkin-info">
                <div class="checkin-type">${item.type || 'scheduled'}</div>
                <div class="checkin-time">${new Date(item.timestamp || item.expectedCheckin).toLocaleString()}</div>
            </div>
            <div class="checkin-status ${item.status}">${item.status}</div>
        </div>
    `).join('');
    
    // Update last check-in on dashboard
    const lastCheckin = sortedHistory.find(item => item.type === 'checkin');
    if (lastCheckin) {
        document.getElementById('lastCheckin').textContent = 
            new Date(lastCheckin.timestamp).toLocaleString();
    }
}

// ===========================================
// SOS FUNCTIONALITY
// ===========================================

function triggerSOS() {
    console.log('SOS Triggered!');
    
    // Get current location and time
    const sosData = {
        location: userLocation || { lat: 0, lng: 0, accuracy: 'unknown' },
        timestamp: Date.now(),
        touristId: digitalId?.touristId || 'Not registered',
        type: 'manual'
    };
    
    // Update SOS modal with current data
    document.getElementById('sosLocation').textContent = 
        userLocation ? `${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}` : 'Location unavailable';
    document.getElementById('sosTime').textContent = new Date().toLocaleString();
    document.getElementById('sosTouristId').textContent = sosData.touristId;
    
    // Show SOS modal
    document.getElementById('sosModal').classList.add('active');
    
    // Store current SOS data for later use
    window.currentSOS = sosData;
}

function triggerAutoSOS(reason) {
    console.log('Auto SOS Triggered:', reason);
    
    const sosData = {
        location: userLocation || { lat: 0, lng: 0, accuracy: 'unknown' },
        timestamp: Date.now(),
        touristId: digitalId?.touristId || 'Not registered',
        type: 'automatic',
        reason: reason
    };
    
    // Directly send SOS without modal for automatic triggers
    sendSOSAlert(sosData);
    generateEFIRForSOS(sosData);
}

function sendSOS() {
    const sosData = window.currentSOS;
    if (!sosData) return;
    
    sendSOSAlert(sosData);
    generateEFIRForSOS(sosData);
}

function sendSOSAlert(sosData) {
    // Add to SOS logs
    const sosLog = {
        id: Date.now(),
        ...sosData,
        status: 'sent',
        responses: []
    };
    
    sosLogs.push(sosLog);
    saveData('sosLogs', sosLogs);
    updateSosLogsList();
    updateDashboard();
    
    // TODO: Integrate with real SMS/WhatsApp/emergency services API
    console.log('SOS Alert Payload:', sosLog);
    
    // TODO: Send to LoRa/Satellite for offline communication
    console.log('TODO: Send via LoRa/Satellite:', sosLog);
    
    showToast('SOS Alert sent successfully!', 'success');
    
    // Mock emergency response
    setTimeout(() => {
        showToast('Emergency services notified', 'info');
    }, 2000);
}

function generateEFIR() {
    if (window.currentSOS) {
        generateEFIRForSOS(window.currentSOS);
    }
}

function generateEFIRForSOS(sosData) {
    const efir = generateEFIRDocument(sosData, 'SOS Alert');
    downloadEFIR(efir, `EFIR_SOS_${sosData.touristId}_${Date.now()}.txt`);
}

function generateEFIRForMissedCheckin(schedule) {
    const efir = generateEFIRDocument({
        location: userLocation,
        timestamp: Date.now(),
        touristId: digitalId?.touristId || 'Not registered'
    }, 'Missed Check-in', schedule);
    
    downloadEFIR(efir, `EFIR_MissedCheckin_${digitalId?.touristId}_${Date.now()}.txt`);
}

function generateEFIRDocument(sosData, type, additionalData = null) {
    const efir = `
E-FIR (Electronic First Information Report)
===========================================

Report Type: ${type}
Report ID: EFIR-${Date.now()}
Generated: ${new Date().toLocaleString()}

TOURIST INFORMATION:
-------------------
Tourist ID: ${sosData.touristId}
${digitalId ? `
Name: ${digitalId.fullName}
ID Number: ${digitalId.idNumber}
Tourist Type: ${digitalId.touristType}
Emergency Contact: ${digitalId.emergencyContact}
Trip Period: ${digitalId.tripStart} to ${digitalId.tripEnd}
Hotel Details: ${digitalId.hotelDetails || 'Not provided'}
Vehicle/Driver Info: ${digitalId.vehicleInfo || 'Not provided'}
` : 'Digital ID not registered'}

INCIDENT DETAILS:
----------------
Timestamp: ${new Date(sosData.timestamp).toLocaleString()}
Location: ${sosData.location ? `${sosData.location.lat}, ${sosData.location.lng}` : 'Location unavailable'}
Location Accuracy: ${sosData.location?.accuracy || 'Unknown'}
Incident Type: ${type}
${sosData.reason ? `Reason: ${sosData.reason}` : ''}
${additionalData ? `Additional Info: ${JSON.stringify(additionalData, null, 2)}` : ''}

SYSTEM INFORMATION:
------------------
Application: SafeTour Tourist Safety System
Report Generated By: Automated System
Last Known Location Update: ${userLocation ? new Date(userLocation.timestamp).toLocaleString() : 'Never'}
Active Tracking: ${trackingActive ? 'Yes' : 'No'}

RECENT ACTIVITY:
---------------
${checkinHistory.slice(-3).map(item => 
    `${item.type || 'scheduled'} - ${new Date(item.timestamp || item.expectedCheckin).toLocaleString()}`
).join('\n')}

PLANNED DESTINATIONS:
--------------------
${destinations.map(dest => 
    `${dest.name} - ${dest.lat}, ${dest.lng} - Planned: ${new Date(dest.visitTime).toLocaleString()}`
).join('\n')}

---
This is an automatically generated E-FIR from SafeTour Tourist Safety System.
For assistance, contact emergency services immediately.
Generated at: ${new Date().toISOString()}
    `.trim();
    
    return efir;
}

function downloadEFIR(efire, filename) {
    const blob = new Blob([efire], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('E-FIR generated and downloaded', 'info');
}

function dismissSOS() {
    const password = document.getElementById('sosPassword').value;
    
    // Simple password check (in production, this should be more secure)
    if (password === 'safe123' || (digitalId && password === digitalId.touristId)) {
        document.getElementById('sosModal').classList.remove('active');
        document.getElementById('sosPassword').value = '';
        showToast('SOS dismissed', 'info');
    } else {
        showToast('Incorrect password', 'error');
    }
}

// ===========================================
// FIRST AID FUNCTIONALITY
// ===========================================

function showFirstAidGuide(type) {
    const guides = {
        snakebite: {
            title: 'Snake Bite First Aid',
            content: `
                <div class="first-aid-guide">
                    <h3>Immediate Actions:</h3>
                    <ol>
                        <li>Keep calm and still - movement spreads venom</li>
                        <li>Remove jewelry from affected limb before swelling</li>
                        <li>Position affected limb below heart level</li>
                        <li>Clean wound gently with soap and water</li>
                        <li>Cover with clean, dry bandage</li>
                        <li>Call emergency services immediately</li>
                    </ol>
                    
                    <h3>DO NOT:</h3>
                    <ul>
                        <li>Cut the wound or try to suck out venom</li>
                        <li>Apply ice or heat</li>
                        <li>Use a tourniquet</li>
                        <li>Give alcohol or drugs</li>
                        <li>Try to catch or kill the snake</li>
                    </ul>
                    
                    <div class="emergency-note">
                        <strong>⚠️ This is a medical emergency requiring immediate professional treatment</strong>
                    </div>
                </div>
            `
        },
        burns: {
            title: 'Burn Treatment',
            content: `
                <div class="first-aid-guide">
                    <h3>For Minor Burns:</h3>
                    <ol>
                        <li>Cool the burn with cool (not cold) water for 10-15 minutes</li>
                        <li>Remove rings or tight items before swelling</li>
                        <li>Apply moisturizer or aloe vera</li>
                        <li>Cover with sterile bandage</li>
                        <li>Take over-the-counter pain medication if needed</li>
                    </ol>
                    
                    <h3>For Severe Burns:</h3>
                    <ol>
                        <li>Call emergency services immediately</li>
                        <li>Don't remove burned clothing</li>
                        <li>Cover with cool, moist cloth</li>
                        <li>Elevate burned area above heart if possible</li>
                        <li>Watch for shock symptoms</li>
                    </ol>
                    
                    <div class="emergency-note">
                        <strong>Seek immediate medical attention for burns larger than 2 inches or on face, hands, feet, or genitals</strong>
                    </div>
                </div>
            `
        },
        hypothermia: {
            title: 'Hypothermia Treatment',
            content: `
                <div class="first-aid-guide">
                    <h3>Immediate Actions:</h3>
                    <ol>
                        <li>Move person to warm, dry area</li>
                        <li>Remove wet clothing carefully</li>
                        <li>Cover with blankets, leaving face exposed</li>
                        <li>Give warm, sweet drinks (if conscious)</li>
                        <li>Apply warm compresses to chest, neck, head</li>
                        <li>Get medical help immediately</li>
                    </ol>
                    
                    <h3>Warning Signs:</h3>
                    <ul>
                        <li>Uncontrollable shivering</li>
                        <li>Confusion or memory loss</li>
                        <li>Slurred speech</li>
                        <li>Drowsiness</li>
                        <li>Weak pulse</li>
                    </ul>
                    
                    <div class="emergency-note">
                        <strong>⚠️ Severe hypothermia is life-threatening - call emergency services immediately</strong>
                    </div>
                </div>
            `
        },
        fractures: {
            title: 'Fracture Management',
            content: `
                <div class="first-aid-guide">
                    <h3>Immediate Care:</h3>
                    <ol>
                        <li>Don't move the person unless necessary</li>
                        <li>Immobilize the injured area</li>
                        <li>Apply ice wrapped in cloth (not directly on skin)</li>
                        <li>Check for circulation below the injury</li>
                        <li>Control bleeding with direct pressure</li>
                        <li>Call emergency services</li>
                    </ol>
                    
                    <h3>Signs of Fracture:</h3>
                    <ul>
                        <li>Severe pain</li>
                        <li>Visible deformity</li>
                        <li>Inability to move normally</li>
                        <li>Swelling and bruising</li>
                        <li>Bone protruding through skin</li>
                    </ul>
                    
                    <div class="emergency-note">
                        <strong>Do not attempt to straighten a broken bone or push protruding bones back in</strong>
                    </div>
                </div>
            `
        },
        allergic: {
            title: 'Allergic Reaction Treatment',
            content: `
                <div class="first-aid-guide">
                    <h3>For Severe Allergic Reaction (Anaphylaxis):</h3>
                    <ol>
                        <li>Call emergency services immediately</li>
                        <li>Use epinephrine auto-injector if available</li>
                        <li>Have person lie flat with legs elevated</li>
                        <li>Loosen tight clothing</li>
                        <li>Cover with blanket but don't overheat</li>
                        <li>Monitor breathing and pulse</li>
                    </ol>
                    
                    <h3>Symptoms to Watch For:</h3>
                    <ul>
                        <li>Difficulty breathing or wheezing</li>
                        <li>Swelling of face, lips, tongue, throat</li>
                        <li>Rapid, weak pulse</li>
                        <li>Widespread rash or hives</li>
                        <li>Nausea, vomiting, or diarrhea</li>
                        <li>Dizziness or fainting</li>
                    </ul>
                    
                    <div class="emergency-note">
                        <strong>⚠️ Anaphylaxis can be fatal within minutes - act quickly!</strong>
                    </div>
                </div>
            `
        },
        altitude: {
            title: 'Altitude Sickness Treatment',
            content: `
                <div class="first-aid-guide">
                    <h3>Immediate Treatment:</h3>
                    <ol>
                        <li>Stop ascending immediately</li>
                        <li>Rest and avoid physical activity</li>
                        <li>Drink plenty of water</li>
                        <li>Avoid alcohol and sleeping pills</li>
                        <li>Take pain medication for headache</li>
                        <li>Descend if symptoms worsen</li>
                    </ol>
                    
                    <h3>Symptoms:</h3>
                    <ul>
                        <li>Headache</li>
                        <li>Nausea and vomiting</li>
                        <li>Fatigue and weakness</li>
                        <li>Dizziness</li>
                        <li>Difficulty sleeping</li>
                    </ul>
                    
                    <h3>Severe Symptoms (Emergency):</h3>
                    <ul>
                        <li>Severe shortness of breath</li>
                        <li>Confusion or loss of coordination</li>
                        <li>Coughing up blood</li>
                        <li>Severe headache with vomiting</li>
                    </ul>
                    
                    <div class="emergency-note">
                        <strong>Descend immediately if severe symptoms develop</strong>
                    </div>
                </div>
            `
        }
    };
    
    const guide = guides[type];
    if (!guide) return;
    
    document.getElementById('firstAidTitle').textContent = guide.title;
    document.getElementById('firstAidContent').innerHTML = guide.content;
    document.getElementById('firstAidModal').classList.add('active');
}

function searchFirstAid() {
    const query = document.getElementById('firstAidSearch').value.toLowerCase();
    const cards = document.querySelectorAll('.first-aid-card');
    
    cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(query) ? 'block' : 'none';
    });
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// ===========================================
// UTILITY FUNCTIONS
// ===========================================

function switchSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show target section
    document.getElementById(sectionId).classList.add('active');
    
    // Update navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
    
    // Close mobile menu
    document.getElementById('sidebar').classList.remove('active');
}

function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;
    
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    
    return R * c;
}

function checkRouteDeviations() {
    if (!userLocation || destinations.length === 0) return;
    
    // Find the next planned destination
    const now = Date.now();
    const upcomingDestination = destinations.find(dest => 
        new Date(dest.visitTime).getTime() > now - 3600000 && // Within an hour of planned time
        new Date(dest.visitTime).getTime() < now + 3600000
    );
    
    if (upcomingDestination) {
        const distance = calculateDistance(
            userLocation.lat, userLocation.lng,
            upcomingDestination.lat, upcomingDestination.lng
        );
        
        // If more than 1km away from planned destination during visit window
        if (distance > 1000) {
            const lastDeviation = localStorage.getItem(`deviation_${upcomingDestination.id}`);
            if (!lastDeviation || (now - parseInt(lastDeviation)) > 600000) { // 10 minutes between alerts
                localStorage.setItem(`deviation_${upcomingDestination.id}`, now.toString());
                
                if (confirm(`You seem to have deviated from your planned destination: ${upcomingDestination.name}. Are you safe?`)) {
                    showToast('Thank you for confirming your safety', 'success');
                } else {
                    triggerAutoSOS(`Route deviation from ${upcomingDestination.name}`);
                }
            }
        }
    }
}

function updateDashboard() {
    // Update ID status
    const idStatus = document.getElementById('idStatus');
    if (digitalId) {
        idStatus.textContent = 'Registered';
        idStatus.className = 'status-badge active';
    } else {
        idStatus.textContent = 'Not Registered';
        idStatus.className = 'status-badge';
    }
    
    // Update stats
    document.getElementById('plannedDestinations').textContent = destinations.length;
    document.getElementById('restrictedZones').textContent = restrictedZones.length;
    document.getElementById('sosCount').textContent = sosLogs.length;
}

function updateSosLogsList() {
    const container = document.getElementById('sosLogsList');
    
    if (sosLogs.length === 0) {
        container.innerHTML = '<p class="empty-state">No SOS alerts recorded</p>';
        return;
    }
    
    container.innerHTML = sosLogs.slice(-10).reverse().map(log => `
        <div class="sos-log-item">
            <div class="log-details">
                <h4>SOS Alert - ${log.type}</h4>
                <div class="log-meta">
                    ${new Date(log.timestamp).toLocaleString()} | 
                    Location: ${log.location.lat?.toFixed(4) || 'N/A'}, ${log.location.lng?.toFixed(4) || 'N/A'}
                    ${log.reason ? ` | Reason: ${log.reason}` : ''}
                </div>
            </div>
            <div class="log-actions">
                <button class="item-btn" onclick="downloadSOSLog(${sosLogs.indexOf(log)})" title="Download">
                    <i class="fas fa-download"></i>
                </button>
            </div>
        </div>
    `).join('');
}

function downloadSOSLog(index) {
    const log = sosLogs[index];
    if (!log) return;
    
    const logData = {
        ...log,
        exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(logData, null, 2)], {
        type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SOS_Log_${log.timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('SOS log downloaded', 'success');
}

function downloadAllLogs() {
    const allData = {
        digitalId: digitalId,
        sosLogs: sosLogs,
        checkinHistory: checkinHistory,
        destinations: destinations,
        restrictedZones: restrictedZones,
        exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(allData, null, 2)], {
        type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SafeTour_AllLogs_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('All logs downloaded', 'success');
}

function clearLogs() {
    if (confirm('Are you sure you want to clear all SOS logs? This action cannot be undone.')) {
        sosLogs = [];
        saveData('sosLogs', sosLogs);
        updateSosLogsList();
        updateDashboard();
        showToast('SOS logs cleared', 'info');
    }
}

// ===========================================
// VOICE ASSISTANT & INTERNATIONALIZATION
// ===========================================

let voiceActive = false;

function toggleVoiceAssistant() {
    const button = document.getElementById('voiceButton');
    
    if (!voiceActive) {
        // Start voice recognition
        voiceActive = true;
        button.classList.add('active');
        showToast('Voice assistant activated (Mock)', 'info');
        
        // TODO: Implement speech-to-text
        console.log('TODO: Implement speech recognition');
        
        // Mock voice recognition
        setTimeout(() => {
            voiceActive = false;
            button.classList.remove('active');
            showToast('Voice assistant deactivated', 'info');
        }, 3000);
    } else {
        // Stop voice recognition
        voiceActive = false;
        button.classList.remove('active');
        showToast('Voice assistant deactivated', 'info');
    }
}

// Internationalization object
const i18n = {
    en: {
        // Navigation
        navigation: 'Navigation',
        dashboard: 'Dashboard',
        digitalId: 'Digital ID',
        liveMap: 'Live Map',
        exploration: 'Exploration',
        restrictedZones: 'Restricted Zones',
        hotelCheckin: 'Hotel Check-in',
        firstAid: 'First Aid',
        sosLogs: 'SOS Logs',
        
        // Dashboard
        welcomeToDashboard: 'Welcome to SafeTour Dashboard',
        dashboardSubtitle: 'Your comprehensive tourist safety companion',
        touristStatus: 'Tourist Status',
        digitalIdStatus: 'Digital ID Status:',
        lastCheckin: 'Last Check-in:',
        currentLocation: 'Current Location:',
        safetyStats: 'Safety Statistics',
        plannedDestinations: 'Planned Destinations',
        restrictedZonesNearby: 'Restricted Zones Nearby',
        sosAlerts: 'SOS Alerts',
        quickActions: 'Quick Actions',
        registerDigitalId: 'Register Digital ID',
        planExploration: 'Plan Exploration',
        
        // Common
        home: 'Home',
        map: 'Map',
        id: 'ID',
        aid: 'Aid'
    },
    hi: {
        // Navigation (Hindi)
        navigation: 'नेविगेशन',
        dashboard: 'डैशबोर्ड',
        digitalId: 'डिजिटल आईडी',
        liveMap: 'लाइव मैप',
        exploration: 'अन्वेषण',
        restrictedZones: 'प्रतिबंधित क्षेत्र',
        hotelCheckin: 'होटल चेक-इन',
        firstAid: 'प्राथमिक चिकित्सा',
        sosLogs: 'एसओएस लॉग',
        
        // Dashboard (Hindi)
        welcomeToDashboard: 'सेफटूर डैशबोर्ड में आपका स्वागत है',
        dashboardSubtitle: 'आपका व्यापक पर्यटक सुरक्षा साथी',
        touristStatus: 'पर्यटक स्थिति',
        digitalIdStatus: 'डिजिटल आईडी स्थिति:',
        lastCheckin: 'अंतिम चेक-इन:',
        currentLocation: 'वर्तमान स्थान:',
        safetyStats: 'सुरक्षा आंकड़े',
        plannedDestinations: 'नियोजित गंतव्य',
        restrictedZonesNearby: 'आसपास के प्रतिबंधित क्षेत्र',
        sosAlerts: 'एसओएस अलर्ट',
        quickActions: 'त्वरित क्रियाएं',
        registerDigitalId: 'डिजिटल आईडी पंजीकृत करें',
        planExploration: 'अन्वेषण की योजना बनाएं',
        
        // Common (Hindi)
        home: 'होम',
        map: 'मैप',
        id: 'आईडी',
        aid: 'सहायता'
    }
};

function initializeI18n() {
    updateLanguageText();
}

function toggleLanguage() {
    currentLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    localStorage.setItem('language', currentLanguage);
    
    document.getElementById('langText').textContent = currentLanguage.toUpperCase();
    updateLanguageText();
    showToast(`Language switched to ${currentLanguage === 'en' ? 'English' : 'Hindi'}`, 'info');
}

function updateLanguageText() {
    const texts = i18n[currentLanguage];
    
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (texts[key]) {
            element.textContent = texts[key];
        }
    });
}

// ===========================================
// PERIODIC CHECKS & MONITORING
// ===========================================

function setupPeriodicChecks() {
    // Check for missed check-ins every 5 minutes
    setInterval(checkScheduledCheckins, 300000);
    
    // Update location tracking status every minute
    setInterval(updateTrackingStatus, 60000);
    
    // Check for expired Digital ID
    setInterval(checkDigitalIdExpiry, 3600000); // Every hour
}

function checkScheduledCheckins() {
    const now = Date.now();
    
    checkinHistory.forEach(item => {
        if (item.status === 'scheduled' && item.expectedCheckin) {
            const timeSinceExpected = now - item.expectedCheckin;
            
            // If 30 minutes past expected check-in time
            if (timeSinceExpected > 1800000 && timeSinceExpected < 1860000) { // 30-31 minutes
                checkMissedCheckin(item);
            }
        }
    });
}

function updateTrackingStatus() {
    if (userLocation) {
        const timeSinceUpdate = Date.now() - userLocation.timestamp;
        
        if (timeSinceUpdate > 300000) { // 5 minutes
            showToast('Location tracking may be interrupted', 'warning');
        }
    }
}

function checkDigitalIdExpiry() {
    if (digitalId && digitalId.tripEnd) {
        const endDate = new Date(digitalId.tripEnd);
        const now = new Date();
        
        if (now > endDate) {
            showToast('Your Digital Tourist ID has expired', 'warning');
            // TODO: Auto-archive expired ID
        } else if ((endDate - now) < 86400000) { // 24 hours
            showToast('Your Digital Tourist ID expires soon', 'info');
        }
    }
}

// ===========================================
// TOAST NOTIFICATIONS
// ===========================================

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    }[type];
    
    toast.innerHTML = `
        <i class="${icon}"></i>
        <span>${message}</span>
    `;
    
    const container = document.getElementById('toastContainer');
    container.appendChild(toast);
    
    // Remove toast after 5 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 5000);
}

// ===========================================
// COMMUNITY SAFETY (Mock Implementation)
// ===========================================

function simulateNearbyTourists() {
    if (!userLocation || !map) return;
    
    // Add mock nearby tourists
    for (let i = 0; i < 3; i++) {
        const lat = userLocation.lat + (Math.random() - 0.5) * 0.01;
        const lng = userLocation.lng + (Math.random() - 0.5) * 0.01;
        
        const marker = L.marker([lat, lng], {
            icon: L.divIcon({
                className: 'nearby-tourist-marker',
                html: '<i class="fas fa-users" style="color: #8b5cf6;"></i>',
                iconSize: [16, 16]
            })
        }).addTo(map);
        
        marker.bindPopup(`
            <div class="marker-popup">
                <h4>Nearby Tourist</h4>
                <p>Last seen: ${new Date().toLocaleTimeString()}</p>
                <p>Status: Safe</p>
            </div>
        `);
    }
}

// Initialize nearby tourists simulation when map is ready
setTimeout(simulateNearbyTourists, 5000);

// ===========================================
// EXPORT FOR TESTING
// ===========================================

// Make functions available globally for testing
window.SafeTourApp = {
    switchSection,
    triggerSOS,
    showFirstAidGuide,
    toggleVoiceAssistant,
    centerOnUser,
    toggleTracking,
    performCheckin,
    performCheckout
};

console.log('SafeTour App Loaded Successfully! 🚀');